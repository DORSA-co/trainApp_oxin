

from traceback import print_tb


print('%s '*5)