
from faulthandler import disable


successfull_green = '#78AD40'
failed_red = '#FF1111'
disabled_btn = '#8D8D8D'
black = '#000000'