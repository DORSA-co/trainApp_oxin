from PySide6.QtCore import Qt

KEYS = {


    Qt.Key_6: 'right',
    Qt.Key_4: 'left', 
    Qt.Key_8: 'up',
    Qt.Key_2: 'down',

    # Qt.Key_1: 'n1',
    # Qt.Key_2: 'n2',
    # Qt.Key_3: 'n3',
    # Qt.Key_4: 'n4',
    # Qt.Key_5: 'n5',
    # Qt.Key_6: 'n6',
    # Qt.Key_7: 'n7',
    # Qt.Key_8: 'n8',
    # Qt.Key_9: 'n9',
  

}
