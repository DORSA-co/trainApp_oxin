PAGES_IDX = {

    0:'Technical View'


 }